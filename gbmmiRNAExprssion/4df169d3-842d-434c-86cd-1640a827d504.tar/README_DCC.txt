README for Data-Matrix-Generated Archive

Your download includes one or more SDRF files. For information on how to use the information contained in this type of file, please see this TCGA Encyclopedia entry: https://wiki.nci.nih.gov/x/9aFXAg 
